﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bridge
{
    class Program
    {
        static void Main(string[] args)
        {
            int secilen;
            //su faturası ödemesi 
            FaturaYonetimAbstraction faturaYonetim =new FaturaKopru();
            do
            {

                Console.WriteLine("\nÖdenecek Faturayı Seçiniz:\n-----------------------------");
                Console.WriteLine("1-Su Faturası");
                Console.WriteLine("2-Elektrik Faturası");
                Console.WriteLine("3-Çıkış Yap");
                secilen = Convert.ToInt32(Console.ReadLine());

                switch (secilen)
                {
                    case 1:
                        Console.Clear();
                        Console.WriteLine("-------------------------");

                        faturaYonetim._ode = new SuFaturasiOde();
                        faturaYonetim.Ode();

                        secilen = 0;
                        break;
                    case 2:
                        Console.Clear();
                        Console.WriteLine("-------------------------");

                        //elektrik faturası ödemesi
                        faturaYonetim._ode = new ElektrikFaturasiOde();
                        faturaYonetim.Ode();

                        secilen = 0;
                        break;
                    
                    case 3:
                        Environment.Exit(0);
                        break;

                    default:
                        Console.Clear();
                        Console.WriteLine("-------------------------");
                        Console.WriteLine("Böyle Bir Seçenek Yok!!");

                        break;
                }
                Console.WriteLine("-------------------------\n");
            } while (secilen > 3 || secilen <= 0);






            
            

            Console.ReadLine();
        }
    }
}
