﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace bir_kelime_oyunu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        List<string> olusan_kelimeler = new List<string>();

        Random rnd = new Random();
   
            string[] harfler = { "A", "B", "C" , "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "R", "S", "T", "U", "V", "Y", "Z" };

        string k1, k2, k3, k4, k5, k6, k7, k8;



        //yenile butonu // burda yeni harfler döndürüyoruz
        private void button11_Click(object sender, EventArgs e)
        {
            
            button1.Text = Convert.ToString(harfler[rnd.Next(0, 23)]);
            button2.Text = Convert.ToString(harfler[rnd.Next(0, 23)]);
            button3.Text = Convert.ToString(harfler[rnd.Next(0, 23)]);
            button4.Text = Convert.ToString(harfler[rnd.Next(0, 23)]);
            button5.Text = Convert.ToString(harfler[rnd.Next(0, 23)]);
            button6.Text = Convert.ToString(harfler[rnd.Next(0, 23)]);
            button7.Text = Convert.ToString(harfler[rnd.Next(0, 23)]);
            button8.Text = Convert.ToString(harfler[rnd.Next(0, 23)]);
            button9.Text = "Joker ";

            k1 = button1.Text;
            k2 = button2.Text;
            k3 = button3.Text;
            k4 = button4.Text;
            k5 = button5.Text;
            k6 = button6.Text;
            k7 = button7.Text;
            k8 = button8.Text;
            listBox1.Items.Clear();
        }
        // form başlangıcı // burda yeni harfler döndürüyoruz
        private void Form1_Load(object sender, EventArgs e)
        {
        
            button1.Text = Convert.ToString(harfler[rnd.Next(0, 23)]);
            button2.Text = Convert.ToString(harfler[rnd.Next(0, 23)]);
            button3.Text = Convert.ToString(harfler[rnd.Next(0, 23)]);
            button4.Text = Convert.ToString(harfler[rnd.Next(0, 23)]);
            button5.Text = Convert.ToString(harfler[rnd.Next(0, 23)]);
            button6.Text = Convert.ToString(harfler[rnd.Next(0, 23)]);
            button7.Text = Convert.ToString(harfler[rnd.Next(0, 23)]);
            button8.Text = Convert.ToString(harfler[rnd.Next(0, 23)]);
            button9.Text = "Joker ";

            k1 = button1.Text;
            k2 = button2.Text;
            k3 = button3.Text;
            k4 = button4.Text;
            k5 = button5.Text;
            k6 = button6.Text;
            k7 = button7.Text;
            k8 = button8.Text;
            
        }

        
        //basla butonu
        private void button10_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            int esit=0,hrfsys=0 ;
            
          //Okuma işlem yapacağımız dosyanın yolunu belirtiyoruz.
                string dosya_yolu = @"C:\Users\Monster\OneDrive\Masaüstü\kelimeler.txt";
          
            string[] kelimeler = System.IO.File.ReadAllLines(dosya_yolu, Encoding.GetEncoding("windows-1254"));

            bool tekrar =false;
            foreach (string kelime in kelimeler)
            {
                string [] dizi = { k1, k2, k3, k4, k5, k6, k7, k8 };
                esit = 0;
                hrfsys = 0;
                //Dosyamızdan okunan kelimeler burda kaç harflli olduğu bulunuyor
                foreach (char c in kelime.ToCharArray())
                {
                    hrfsys ++;
                }

                //Algoritma başlar:txt deki ilk kelimeyi harflere ayırır dizi de tuttuğumuz random 
                //kelimelerle karşılaştırır eğer harf sayısı eşitse veya bir harf eksikse(eksik harfi 
                //joker ile tamamlıyoruz) harfleri oluşan kelimeler listesine atar.

                foreach (char c in kelime.ToCharArray())
                    {
                    tekrar = false;
                        for (int i = 0; i < 8; i++)
                        {
                            if(c.ToString()==dizi[i].ToString())
                            {
                              esit++;
                            //MessageBox.Show(c.ToString());
                            tekrar = true;
                            dizi[i] ="x";
                            }
                        if (tekrar == true)
                            break;
                        }
   
                    }
                if(esit==hrfsys || esit+1 == hrfsys)
                {
                    olusan_kelimeler.Add(kelime);
                    listBox1.Items.Add(kelime);
                }
                
            }
            int uzunluk=0;
            //Burda en uzun kelime bulunur ve  textbox1 ye yazılır.
            foreach (string ols_klm in olusan_kelimeler)
            {
                if (ols_klm.Length > uzunluk)
                {

                    textBox1.Text = ols_klm;
                    uzunluk = ols_klm.Length;
                    
                }
                
            }
            olusan_kelimeler.Clear();
            //Burda alınan puanlar belirtilip textbox2 ye yazılır.
            switch (uzunluk)
                {
                    case 3:
                        textBox2.Text = "3";
                        break;
                    case 4:
                        textBox2.Text = "4";
                        break;
                    case 5:
                        textBox2.Text = "5";
                        break;
                    case 6:
                        textBox2.Text = "7";
                        break;
                    case 7:
                        textBox2.Text = "9";
                        break;
                    case 8:
                        textBox2.Text = "11";
                        break;
                    case 9:
                        textBox2.Text = "15";
                        break;


                    default:
                        break;
                }

           



          
        }
           
       private void button12_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);

        }
        

     
        


    }
    }

