﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public int kalan_bul(int [] dizi,int kalan)
        {
            int bulundu_kalan = 0;
            
            

            //kalanı verilen sayılardan bulma
            for (int i = 0; i < 6; i++)
            {
                if (dizi[i] == kalan)
                {
                    kalan = dizi[i] ;
                    bulundu_kalan = 1;
                    
                }
                if (bulundu_kalan == 1) break;
            }
            //kalan değerini çarpma ile bulma bölümü
            if (bulundu_kalan != 1)
            {
                for (int i = 0; i < 6; i++)
                {


                    for (int j = 0; j < 6; j++)
                    {
                        if ((dizi[i] * dizi[j]) == kalan)
                        {
                            kalan = (dizi[i] * dizi[j]);
                            bulundu_kalan = 1;
                            label19.Text += Convert.ToString(dizi[i]) + " * " + Convert.ToString(dizi[j]) + " = " + Convert.ToString(kalan) + "\n";

                            
                          
                        }
                        if (bulundu_kalan == 1) break;
                    }
                    if (bulundu_kalan == 1) break;
                }
            }

            //kalan değerini toplama ile bulma bölümü
            if (bulundu_kalan != 1)
            {
                for (int i = 0; i < 6; i++)
                {


                    for (int j = 0; j < 6; j++)
                    {
                        if ((dizi[i] + dizi[j]) == kalan)
                        {
                            kalan =  (dizi[i] + dizi[j]);
                            bulundu_kalan = 1;
                            label19.Text += Convert.ToString(dizi[i]) + " + " + Convert.ToString(dizi[j]) + " = " + Convert.ToString(kalan) + "\n";

                        }
                        if (bulundu_kalan == 1) break;
                    }
                    if (bulundu_kalan == 1) break;
                }
            }
            //kalan değerini çıkarma ile  bulma bölümü
            if (bulundu_kalan != 1)
            {
                for (int i = 0; i < 6; i++)
                {


                    for (int j = 0; j < 6; j++)
                    {
                        if ((dizi[i] - dizi[j]) == kalan)
                        {
                            kalan = (dizi[i] - dizi[j]);
                            label19.Text += Convert.ToString(dizi[i]) + " - " + Convert.ToString(dizi[j]) + " = " + Convert.ToString(kalan) + "\n";

                            bulundu_kalan = 1;
                           
                        }
                        if (bulundu_kalan == 1) break;
                    }
                    if (bulundu_kalan == 1) break;
                }
            }
            //kalan değerini bölme ile bulma bölümü
            if (bulundu_kalan != 1)
            {
                for (int i = 0; i < 6; i++)
                {


                    for (int j = 0; j < 6; j++)
                    {
                        if ((dizi[i] / dizi[j]) == kalan)
                        {
                            kalan =  (dizi[i] / dizi[j]);
                            label19.Text += Convert.ToString(dizi[i]) + " / " + Convert.ToString(dizi[j]) + " = " + Convert.ToString(kalan) + "\n";
                            bulundu_kalan = 1;
                           
                        }
                        if (bulundu_kalan == 1) break;
                    }
                    if (bulundu_kalan == 1) break;

                }
            }


            //kalanı 3 sayıya dort işlem uygulayark elde etme
            for (int i = 0; i < 6; i++)
            {
                for (int j = 0; j < 6; j++)
                {
                    for (int z = 0; z < 6; z++)
                    {

                        if (dizi[i] + dizi[j] + dizi[z] == kalan)
                        {
                            kalan = dizi[i] + dizi[j] + dizi[z];
                            bulundu_kalan = 1;
                            label19.Text += Convert.ToString(dizi[i]) + " + " + Convert.ToString(dizi[j]) + " + " + Convert.ToString(dizi[z]) + " = " + Convert.ToString(kalan) + "\n";

                            
                        }
                        if (bulundu_kalan == 1) break;

                        if (dizi[i] + dizi[j] - dizi[z] == kalan && bulundu_kalan != 1)
                        {
                            kalan = dizi[i] + dizi[j] - dizi[z];
                            bulundu_kalan = 1;
                            label19.Text += Convert.ToString(dizi[i]) + " + " + Convert.ToString(dizi[j]) + " - " + Convert.ToString(dizi[z]) + " = " + Convert.ToString(kalan) + "\n";

                           
                        }
                        if (bulundu_kalan == 1) break;
                        if (dizi[i] * dizi[j] * dizi[z] == kalan && bulundu_kalan != 1)
                        {
                            kalan = dizi[i] * dizi[j] * dizi[z];
                            bulundu_kalan = 1;
                            label19.Text += Convert.ToString(dizi[i]) + " * " + Convert.ToString(dizi[j]) + " * " + Convert.ToString(dizi[z]) + " = " + Convert.ToString(kalan) + "\n";

                            
                        }
                        if (bulundu_kalan == 1) break;
                        if (dizi[i] * dizi[j] + dizi[z] == kalan && bulundu_kalan != 1)
                        {
                            kalan = dizi[i] * dizi[j] + dizi[z];
                            bulundu_kalan = 1;
                            label19.Text += Convert.ToString(dizi[i]) + " * " + Convert.ToString(dizi[j]) + " + " + Convert.ToString(dizi[z]) + " = " + Convert.ToString(kalan) + "\n";

                          
                        }
                        if (bulundu_kalan == 1) break;
                        if (dizi[i] * dizi[j] - dizi[z] == kalan && bulundu_kalan != 1)
                        {
                            kalan = dizi[i] * dizi[j] - dizi[z];
                            bulundu_kalan = 1;
                            label19.Text += Convert.ToString(dizi[i]) + " * " + Convert.ToString(dizi[j]) + " - " + Convert.ToString(dizi[z]) + " = " + Convert.ToString(kalan) + "\n";

                         
                        }

                        if (bulundu_kalan == 1) break;

                    }

                    if (bulundu_kalan == 1) break;
                }

                if (bulundu_kalan == 1) break;
            }


            if (bulundu_kalan==1)
            {
                return kalan;
            }
            else
            {
               return kalan = 0;
            }
            
        }
        //////////////////////////////FONKSİYON BİTTİ//////////////////////////////////////////////////////
        int s1, s2, s3, s4, s5, s6, hedef, sonuc,carpim;
        //elle ata butonu
        private void button3_Click(object sender, EventArgs e)
        {
            label19.Text = "";
            label8.Visible = true;
            textBox8.Text = "";

            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            textBox8.Text = "";



            if (
                textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" &&
                textBox4.Text != "" && textBox5.Text != "" && textBox6.Text != "" && textBox7.Text != "" &&
                Convert.ToInt32(textBox6.Text) > 9 && Convert.ToInt32(textBox6.Text) < 100 && Convert.ToInt32(textBox6.Text) % 10 == 0 &&
                Convert.ToInt32(textBox7.Text) > 99 && Convert.ToInt32(textBox7.Text) < 1000
                )
            {
                s1 = Convert.ToInt32(textBox1.Text);
                s2 = Convert.ToInt32(textBox2.Text);
                s3 = Convert.ToInt32(textBox3.Text);
                s4 = Convert.ToInt32(textBox4.Text);
                s5 = Convert.ToInt32(textBox5.Text);
                s6 = Convert.ToInt32(textBox6.Text);
                hedef = Convert.ToInt32(textBox7.Text);
            }


        }
        // random buttonu
        private void button2_Click(object sender, EventArgs e)
        {
            label19.Text = "";
            label18.Visible = false;
            label8.Visible = false;
            textBox8.Text = "";

            Random rnd = new Random();

            textBox1.Text = Convert.ToString(rnd.Next(1, 9));
            textBox2.Text = Convert.ToString(rnd.Next(1, 9));
            textBox3.Text = Convert.ToString(rnd.Next(1, 9));
            textBox4.Text = Convert.ToString(rnd.Next(1, 9));
            textBox5.Text = Convert.ToString(rnd.Next(1, 9));
            textBox6.Text = Convert.ToString(rnd.Next(1, 9) * 10);
            textBox7.Text = Convert.ToString(rnd.Next(100, 999));
            s1 = Convert.ToInt32(textBox1.Text);
            s2 = Convert.ToInt32(textBox2.Text);
            s3 = Convert.ToInt32(textBox3.Text);
            s4 = Convert.ToInt32(textBox4.Text);
            s5 = Convert.ToInt32(textBox5.Text);
            s6 = Convert.ToInt32(textBox6.Text);
            hedef = Convert.ToInt32(textBox7.Text);







        }

       
       
        private void Form1_Load(object sender, EventArgs e)
        {
            label8.Visible = false;
        }
        ////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////
        //HESAPLA BUTONU
        ////////////////////////////////////////////////////
        /////////////////////////////////////////
        private void button1_Click(object sender, EventArgs e)
        {
            label18.Visible = false;
            int bulundu = 0;
            sonuc= 0;

            if (
                 textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" &&
                 textBox4.Text != "" && textBox5.Text != "" && textBox6.Text != "" && textBox7.Text != "" &&
                 Convert.ToInt32(textBox6.Text) > 9 && Convert.ToInt32(textBox6.Text) < 100 && Convert.ToInt32(textBox6.Text) % 10 == 0 &&
                 Convert.ToInt32(textBox7.Text) > 99 && Convert.ToInt32(textBox7.Text) < 1000
                 )
            {
                s1 = Convert.ToInt32(textBox1.Text);
                s2 = Convert.ToInt32(textBox2.Text);
                s3 = Convert.ToInt32(textBox3.Text);
                s4 = Convert.ToInt32(textBox4.Text);
                s5 = Convert.ToInt32(textBox5.Text);
                s6 = Convert.ToInt32(textBox6.Text);
                hedef = Convert.ToInt32(textBox7.Text);
                carpim = s1 * s2 * s3 * s4 * s5 * s6;
                if(carpim<hedef)
                {
                    MessageBox.Show("Verilen sayılarla hedef bulunamaz");
                    
                }

                //verilen sayıları disilere atıyoruz
                int[] dizi = { s1, s2, s3, s4, s5, s6, hedef };

                int temp;


                //dizi sıralaması yapıyoruz.
                //////////////////////////////
                for (int i = 1; i < 7; i++)
                {
                    for (int j = 0; j < 7 - i; j++)
                    {
                        if (dizi[j] > dizi[j + 1])
                        {
                            temp = dizi[j];
                            dizi[j] = dizi[j + 1];
                            dizi[j + 1] = temp;
                        }
                        
                    }
                }
                //////////////////////////////////
                ///bu bolumde ise hedef altıncı sayıya bölüyoruz ve gelen 
                ///sonucu dizideki sayılarla eğer varsa çarpıp sonuca atıyoruz.

                int bol,kalan;
                bol = hedef / s6;
                label19.Text = "--------------------------------- \n Bulunması Gerekenler \n ---------------------------------\n";
                label19.Text += Convert.ToString(hedef) + " / " + Convert.ToString(s6) + " = " + Convert.ToString(bol)+ "\n";
                kalan = hedef % s6;
                label19.Text += Convert.ToString(hedef) + " % " + Convert.ToString(s6) + " = " + Convert.ToString(kalan) + "\n";
                label19.Text += "---------------------------------\n";
                bulundu = 0;
                //bol değerini bulan fonksiyonu çağırıyoruz.


               



                for (int i = 0; i < 6; i++)
                {
                    if (dizi[i] == bol)
                    {
                        sonuc = dizi[i] * s6;
                        label19.Text += Convert.ToString(dizi[i]) + " * " + Convert.ToString(s6) + " = " + Convert.ToString(sonuc) + "\n";
                        bulundu = 1;
                        break;
                    }

                }
                //bol değerini çarpma ile bulma bölümü
                 if (bulundu != 1)
                 {
                    for (int i = 0; i < 6; i++)
                    {
                            for (int j = 0; j < 6; j++)
                            {
                                if ((dizi[i]*dizi[j])== bol)
                                {
                                    sonuc = s6 * (dizi[i] * dizi[j]);
                                bulundu = 1;
                                label19.Text += Convert.ToString(s6) + " * " + Convert.ToString(dizi[i])+ " * " + Convert.ToString(dizi[j]) + " = " + Convert.ToString(sonuc) + "\n";
                                                             
                                }
                            if (bulundu == 1) break;
                        }
                        if (bulundu == 1) break;

                    }
                 }
                
                 //bol değerini toplama ile bulma bölümü
                if (bulundu != 1)
                {
                    for (int i = 0; i < 6; i++)
                    {
                        for (int j = 0; j < 6; j++)
                        {
                            if ((dizi[i] + dizi[j]) == bol)
                            {
                                sonuc = s6 * (dizi[i] + dizi[j]);
                                bulundu = 1;
                                label19.Text += Convert.ToString(s6) + " * " + Convert.ToString(dizi[i]) + " + " + Convert.ToString(dizi[j]) + " = " + Convert.ToString(sonuc) + "\n";

                            }
                            if (bulundu == 1) break;
                        }
                        if (bulundu == 1) break;
                    }
                }
                //bol değerini çıkarma ile  bulma bölümü
                if (bulundu != 1)
                {
                    for (int i = 0; i < 6; i++)
                    {


                        for (int j = 0; j < 6; j++)
                        {
                            if ((dizi[i] - dizi[j]) == bol)
                            {
                                sonuc = s6 * (dizi[i] - dizi[j]);
                                label19.Text += Convert.ToString(s6) + " * " + Convert.ToString(dizi[i]) + " - " + Convert.ToString(dizi[j]) + " = " + Convert.ToString(sonuc) + "\n";

                                
                                bulundu = 1;
                         
                            }
                            if (bulundu == 1) break;

                        }
                        if (bulundu == 1) break;

                    }
                }
                //bol değerini bölme ile bulma bölümü
                if (bulundu != 1)
                {
                    for (int i = 0; i < 6; i++)
                    {


                        for (int j = 0; j < 6; j++)
                        {
                            if ((dizi[i] / dizi[j]) == bol)
                            {
                                sonuc = s6 * (dizi[i] / dizi[j]);
                                label19.Text += Convert.ToString(s6) + " * " + Convert.ToString(dizi[i]) + " / "  + Convert.ToString(dizi[j]) + " = " + Convert.ToString(sonuc) + "\n";

                               
                                bulundu = 1;
                              
                            }
                            if (bulundu == 1) break;
                        }
                        if (bulundu == 1) break;
                    }
                }
                //bol değerini  3 sayıya dort işlem yaparak bulma
                for (int i = 0; i < 6; i++)
                {
                    for (int j = 0; j < 6; j++)
                    {
                        for (int z = 0; z < 6; z++)
                        {
                            if (dizi[i] + dizi[j] + dizi[z] == bol)
                            {
                                sonuc =s6* (dizi[i] + dizi[j] + dizi[z]);
                                bulundu = 1;
                                label19.Text += Convert.ToString(dizi[i]) + " + " + Convert.ToString(dizi[j]) + " + " + Convert.ToString(dizi[z]) + " = " + Convert.ToString(bol) + "\n";

                                
                            }
                            if (bulundu == 1) break;
                            if (dizi[i] + dizi[j] - dizi[z] == bol && bulundu!=1)
                            {
                                sonuc = s6*(dizi[i] + dizi[j] - dizi[z]);
                                bulundu = 1;
                                label19.Text += Convert.ToString(dizi[i]) + " + " + Convert.ToString(dizi[j]) + " - " + Convert.ToString(dizi[z]) + " = " + Convert.ToString(bol) + "\n";

                            }
                            if (bulundu == 1) break;
                            if (dizi[i] * dizi[j] + dizi[z] == bol && bulundu != 1)
                            {
                                sonuc = s6 * (dizi[i] * dizi[j] + dizi[z]);
                                bulundu = 1;
                                label19.Text += Convert.ToString(dizi[i]) + " * " + Convert.ToString(dizi[j]) + " + " + Convert.ToString(dizi[z]) + " = " + Convert.ToString(bol) + "\n";

                               
                            }
                            if (bulundu == 1) break;
                            if (dizi[i] * dizi[j] - dizi[z] == bol && bulundu != 1)
                            {
                                sonuc = s6 * (dizi[i] * dizi[j] - dizi[z]);
                                bulundu = 1;
                                label19.Text += Convert.ToString(dizi[i]) + " * " + Convert.ToString(dizi[j]) + " - " + Convert.ToString(dizi[z]) + " = " + Convert.ToString(bol) + "\n";

                                
                            }
                            if (bulundu == 1) break;
                            if (dizi[i] * dizi[j] * dizi[z] == bol && bulundu != 1)
                            {
                                sonuc = s6 * (dizi[i] * dizi[j] * dizi[z]);
                                bulundu = 1;
                                label19.Text += Convert.ToString(dizi[i]) + " * " + Convert.ToString(dizi[j]) + " * " + Convert.ToString(dizi[z]) + " = " + Convert.ToString(bol) + "\n";

                                
                            }

                            if (bulundu == 1) break;

                        }

                        if (bulundu == 1) break;
                    }

                    if (bulundu == 1) break;
                }


                //kalan bulma fonksiyonunu çağırıyoruz
                if (kalan!=0)
                {
                    int ilk_sonuc=sonuc;
                    sonuc= sonuc+ kalan_bul(dizi, kalan);
                    label19.Text += Convert.ToString(ilk_sonuc) + " + " + Convert.ToString(kalan_bul(dizi, kalan)) +  " = " + Convert.ToString(sonuc) + "\n";

                }








                textBox8.Text = Convert.ToString(sonuc);
            }
            else
                MessageBox.Show("lütfen değerleri tam giriniz.");
            
        }
    }
}
